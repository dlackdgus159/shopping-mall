package com.shop.dto;

public class ItemLikeDto {
    private boolean like_check;
}
