package com.shop.service;

import com.shop.dto.*;
import com.shop.entity.Item;
import com.shop.entity.ItemImg;
import com.shop.entity.Item_like_check;
import com.shop.entity.Member;
import com.shop.repository.ItemImgRepository;
import com.shop.repository.ItemLikeRepository;
import com.shop.repository.ItemRepository;
import com.shop.service.ItemImgService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.security.auth.login.LoginException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service // 서비스 클래스임을 나타냅니다.
@Transactional // 이 클래스의 메서드가 트랜잭션 안에서 실행된다는 것을 나타냅니다.
@RequiredArgsConstructor // final 필드에 대해 생성자를 자동으로 생성해주는 Lombok 어노테이션입니다.
public class ItemService {

    private final ItemRepository itemRepository; // 상품 정보를 관리하는 레포지토리
    private final ItemImgService itemImgService; // 상품 이미지를 관리하는 서비스
    private final ItemImgRepository itemImgRepository; // 상품 이미지를 관리하는 레포지토리
    private final ItemLikeRepository itemLikeRepository;
    private final MemberService memberService;

    // 새로운 상품을 저장하는 메서드
    public Long saveItem(ItemFormDto itemFormDto, List<MultipartFile> itemImgFileList) throws Exception{

        //상품 등록
        Item item = itemFormDto.createItem(); // DTO를 통해 생성된 Item 객체
        itemRepository.save(item); // Item 객체를 데이터베이스에 저장

        //이미지 등록
        for(int i=0;i<itemImgFileList.size();i++){ // 업로드된 이미지 파일 리스트를 순회
            ItemImg itemImg = new ItemImg(); // 새로운 ItemImg 객체 생성
            itemImg.setItem(item); // ItemImg 객체에 Item 객체를 설정

            if(i == 0) // 첫 번째 이미지를 대표 이미지로 설정
                itemImg.setRepimgYn("Y");
            else // 나머지 이미지는 일반 이미지로 설정
                itemImg.setRepimgYn("N");

            itemImgService.saveItemImg(itemImg, itemImgFileList.get(i)); // 이미지 파일을 저장
        }

        return item.getId(); // 저장된 Item 객체의 ID를 반환
    }

    // 특정 상품의 상세 정보를 가져오는 메서드
    @Transactional(readOnly = true) // 읽기 전용 트랜잭션으로 실행
    public ItemFormDto getItemDtl(Long itemId){
        List<ItemImg> itemImgList = itemImgRepository.findByItemIdOrderByIdAsc(itemId); // 상품 ID로 상품 이미지 리스트를 가져옴
        List<ItemImgDto> itemImgDtoList = new ArrayList<>(); // ItemImgDto 리스트 생성
        for (ItemImg itemImg : itemImgList) { // 가져온 상품 이미지 리스트를 순회
            ItemImgDto itemImgDto = ItemImgDto.of(itemImg); // ItemImg 객체를 ItemImgDto 객체로 변환
            itemImgDtoList.add(itemImgDto); // ItemImgDto 리스트에 추가
        }

        Item item = itemRepository.findById(itemId) // 상품 ID로 상품을 조회
                .orElseThrow(EntityNotFoundException::new); // 상품이 없으면 예외 발생
        ItemFormDto itemFormDto = ItemFormDto.of(item); // Item 객체를 ItemFormDto 객체로 변환
        itemFormDto.setItemImgDtoList(itemImgDtoList); // ItemFormDto 객체에 이미지 리스트 설정
        return itemFormDto; // ItemFormDto 객체 반환
    }

    // 기존 상품을 업데이트하는 메서드
    public Long updateItem(ItemFormDto itemFormDto, List<MultipartFile> itemImgFileList) throws Exception{
        Item item = itemRepository.findById(itemFormDto.getId()) // 상품 ID로 상품을 조회
                .orElseThrow(EntityNotFoundException::new); // 상품이 없으면 예외 발생
        item.updateItemExceptions(itemFormDto); // Item 객체를 업데이트
        List<Long> itemImgIds = itemFormDto.getItemImgIds(); // ItemFormDto 객체에서 이미지 ID 리스트를 가져옴

        // 이미지 등록
        for(int i=0;i<itemImgFileList.size();i++){ // 업로드된 이미지 파일 리스트를 순회
            itemImgService.updateItemImg(itemImgIds.get(i), // 이미지 파일을 업데이트
                    itemImgFileList.get(i));
        }

        return item.getId(); // 업데이트된 Item 객체의 ID를 반환
    }

    // 관리자용 상품 페이지를 가져오는 메서드
    @Transactional(readOnly = true) // 읽기 전용 트랜잭션으로 실행
    public Page<Item> getAdminItemPage(ItemSearchDto itemSearchDto, Pageable pageable){
        return itemRepository.getAdminItemPage(itemSearchDto, pageable); // 검색 조건과 페이지 정보를 사용하여 상품 페이지를 조회
    }

    // 메인 페이지에 표시할 상품 페이지를 가져오는 메서드
    @Transactional(readOnly = true) // 읽기 전용 트랜잭션으로 실행
    public Page<MainItemDto> getMainItemPage(ItemSearchDto itemSearchDto, Pageable pageable){
        return itemRepository.getMainItemPage(itemSearchDto, pageable); // 검색 조건과 페이지 정보를 사용하여 메인 상품 페이지를 조회
    }

    @Transactional(readOnly = true) // 읽기 전용 트랜잭션으로 실행
    public Page<MainItemDto> getRankPage(ItemSearchDto itemSearchDto, Pageable pageable){
        return itemRepository.getRankPage(itemSearchDto, pageable); // 검색 조건과 페이지 정보를 사용하여 메인 상품 페이지를 조회
    }

    public int item_Like(String itemId) {

        Item item = itemRepository.findById(Long.valueOf(itemId)) // 상품 ID로 상품을 조회
                .orElseThrow(EntityNotFoundException::new);

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();

        Member member = memberService.findByEmail(currentPrincipalName);

        if (member != null) {
            Item_like_check byMemberId = itemLikeRepository.findByMemberId(member.getId(), item.getId());
            if (byMemberId != null && byMemberId.getItem().getId().equals(item.getId())) {
                item.setItemLike(item.getItemLike() - 1);

                itemRepository.save(item);
                itemLikeRepository.deleteItem_Id(item.getId());
                return -1;
            } else {
                item.setItemLike(item.getItemLike() + 1);
                Item_like_check itemLike = Item_like_check.builder()
                        .like_check(true)
                        .member(member)
                        .item(item).build();
                itemLikeRepository.save(itemLike);
                return 1;
            }
        } else
            try {
                throw new LoginException("로그인을 한후에 이용할수 있습니다");
            } catch (LoginException e) {
                throw new RuntimeException(e);
            }


    }

}