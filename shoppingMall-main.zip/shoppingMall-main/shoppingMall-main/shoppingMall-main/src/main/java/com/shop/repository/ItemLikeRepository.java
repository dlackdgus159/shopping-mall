package com.shop.repository;

import com.shop.entity.Item_like_check;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ItemLikeRepository extends JpaRepository<Item_like_check, Long> {

    @Query("select i from Item_like_check i where i.member.id = :memberId and i.item.id=:itemId")
    Item_like_check findByMemberId(@Param("memberId")Long memberId, @Param("itemId")Long itemId);

    @Modifying
    @Query("delete from Item_like_check i where i.item.id=:itemId")
    void deleteItem_Id(@Param("itemId")Long itemId);
}
