package com.shop.controller;

import com.shop.dto.ItemDto;
import com.shop.dto.ItemSearchDto;
import com.shop.entity.Item;
import com.shop.entity.Member;
import com.shop.repository.MemberRepository;
import com.shop.service.ItemLikeServiceImpl;
import com.shop.service.ItemService;
import com.shop.dto.ItemFormDto;
import com.shop.service.MemberService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Optional;

@Controller
@RequiredArgsConstructor
public class ItemController {

    private final ItemService itemService; // ItemService를 주입받습니다.
    private final ItemLikeServiceImpl itemLikeService;
    private final MemberService memberService;

    // 새로운 상품 등록 페이지를 보여줍니다.
    @GetMapping(value = "/admin/item/new")
    public String itemForm(Model model){
        model.addAttribute("itemFormDto", new ItemFormDto()); // 빈 ItemFormDto 객체를 모델에 추가합니다.
        return "item/itemForm"; // itemForm.html 템플릿을 반환합니다.
    }

    // 새로운 상품을 등록합니다.
    @PostMapping(value = "/admin/item/new")
    public String itemNew(@Valid ItemFormDto itemFormDto, BindingResult bindingResult,
                          Model model, @RequestParam("itemImgFile") List<MultipartFile> itemImgFileList){

        if(bindingResult.hasErrors()){
            return "item/itemForm"; // 유효성 검사 오류가 있으면 다시 폼을 보여줍니다.
        }

        if(itemImgFileList.get(0).isEmpty() && itemFormDto.getId() == null){
            model.addAttribute("errorMessage", "첫번째 상품 이미지는 필수 입력 값 입니다.");
            return "item/itemForm"; // 첫 번째 이미지가 없으면 오류 메시지를 보여줍니다.
        }

        try {
            itemService.saveItem(itemFormDto, itemImgFileList); // 상품을 저장합니다.
        } catch (Exception e){
            model.addAttribute("errorMessage", "상품 등록 중 에러가 발생하였습니다.");
            e.printStackTrace();
            return "item/itemForm"; // 저장 중 오류가 발생하면 오류 메시지를 보여줍니다.
        }

        return "redirect:/"; // 성공적으로 저장되면 홈으로 리다이렉트합니다.
    }

    // 특정 상품의 상세 정보를 보여줍니다.
    @GetMapping(value="/admin/item/{itemId}")
    public String itemDtl(@PathVariable("itemId") Long itemId, Model model){

        try {
            ItemFormDto itemFormDto = itemService.getItemDtl(itemId); // 상품의 상세 정보를 가져옵니다.
            model.addAttribute("itemFormDto", itemFormDto); // 모델에 추가합니다.
        } catch(EntityNotFoundException e){
            model.addAttribute("errorMessage", "존재하지 않는 상품입니다.");
            model.addAttribute("itemFormDto", new ItemFormDto());
            return "item/itemForm"; // 상품을 찾을 수 없으면 오류 메시지를 보여줍니다.
        }

        return "item/itemForm"; // itemForm.html 템플릿을 반환합니다.
    }

    // 특정 상품의 상세 정보를 보여줍니다 (일반 사용자용).
    @GetMapping(value = "/item/{itemId}")
    public String itemDtl(Model model, @PathVariable("itemId") Long itemId){
        ItemFormDto itemFormDto = itemService.getItemDtl(itemId); // 상품의 상세 정보를 가져옵니다.

        model.addAttribute("item", itemFormDto); // 모델에 추가합니다.

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();

        Member member = memberService.findByEmail(currentPrincipalName);

        boolean itemCheck = false;

        if (member != null) {
            itemCheck = itemLikeService.isItemCheck(member, itemId);
        }

        model.addAttribute("item_like_check", itemCheck);

        return "item/itemDtl"; // itemDtl.html 템플릿을 반환합니다.
    }

    @GetMapping("/item/likes/{itemId}")
    @ResponseBody
    public ResponseEntity<?> itemLikes(@PathVariable String itemId){
//    public ResponseEntity<?> itemLikes(@RequestBody ItemDto itemDto){

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();
        System.out.println(currentPrincipalName);

        try{
            int num = itemService.item_Like(itemId);
            return ResponseEntity.ok(num);
        }catch(EntityNotFoundException e){
            return ResponseEntity.notFound().build();
        }
    }


    // 특정 상품을 업데이트합니다.
    @PostMapping(value = "/admin/item/{itemId}")
    public String itemUpdate(@Valid ItemFormDto itemFormDto, BindingResult bindingResult,
                             @RequestParam("itemImgFile") List<MultipartFile> itemImgFileList, Model model){
        if(bindingResult.hasErrors()){
            return "item/itemForm"; // 유효성 검사 오류가 있으면 다시 폼을 보여줍니다.
        }

        if(itemImgFileList.get(0).isEmpty() && itemFormDto.getId() == null){
            model.addAttribute("errorMessage", "첫번째 상품 이미지는 필수 입력 값 입니다.");
            return "item/itemForm"; // 첫 번째 이미지가 없으면 오류 메시지를 보여줍니다.
        }

        try {
            itemService.updateItem(itemFormDto, itemImgFileList); // 상품을 업데이트합니다.
        } catch (Exception e){
            e.printStackTrace();
            model.addAttribute("errorMessage", "상품 수정 중 에러가 발생하였습니다.");
            return "item/itemForm"; // 업데이트 중 오류가 발생하면 오류 메시지를 보여줍니다.
        }

        return "redirect:/"; // 성공적으로 업데이트되면 홈으로 리다이렉트합니다.
    }

    // 상품 관리 페이지를 보여줍니다.
    @GetMapping(value = {"/admin/items", "/admin/items/{page}"})
    public String itemManage(ItemSearchDto itemSearchDto, @PathVariable("page") Optional<Integer> page, Model model){

        Pageable pageable = PageRequest.of(page.isPresent() ? page.get() : 0, 3); // 페이지 정보를 설정합니다.
        Page<Item> items = itemService.getAdminItemPage(itemSearchDto, pageable); // 페이지네이션을 적용하여 상품 목록을 가져옵니다.

        model.addAttribute("items", items); // 모델에 상품 목록을 추가합니다.
        model.addAttribute("itemSearchDto", itemSearchDto); // 모델에 검색 조건을 추가합니다.
        model.addAttribute("maxPage", 5); // 최대 페이지 번호를 모델에 추가합니다.

        return "item/itemMng"; // itemMng.html 템플릿을 반환합니다.
    }
}