package com.shop.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Item_like_check extends BaseEntity{
    @Id
    @GeneratedValue
    @Column(name = "item_like_Id")
    private Long id;

    private boolean like_check;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "item_id")
    private Item item;

    @OneToOne()
    @JoinColumn(name = "member_Id")
    private Member member;
}
