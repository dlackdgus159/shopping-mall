package com.shop.constant;

public enum ItemSellStatus {
    SELL, SOLD_OUT // SELL : 판매 중인 상품, SOLD_OUT : 품절 상품
}
