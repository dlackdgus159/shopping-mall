package com.shop.service;

import com.shop.entity.Item_like_check;
import com.shop.entity.Member;
import com.shop.repository.ItemLikeRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Transactional
public class ItemLikeServiceImpl {
    private final ItemLikeRepository itemLikeRepository;
    private final MemberService memberService;

    public boolean isItemCheck(Member loginMember, Long itemId ){

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();

        Member member = memberService.findByEmail(currentPrincipalName);

        Item_like_check itemLike = itemLikeRepository.findByMemberId(member.getId(), itemId);
        if (itemLike != null && itemLike.isLike_check()) {
            return true;
        }
        return false;
    }

    public void deleteByItemId(Long itemId){
        itemLikeRepository.deleteItem_Id(itemId);
    }
}
